package com.example.dikakotlin

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun submit_btn(view: View){
        val nameEditText = findViewById<EditText>(R.id.name_edit_text)
        val dika = "Halo " + nameEditText.text.toString() + " Selamat Datang :)"

        val toast_name = Toast.makeText(applicationContext, dika, Toast.LENGTH_SHORT)

        toast_name.show()
    }
}